#COM110: vowelCounter.py
#This program count the number of vowel occurrence in the file

def vowelCounter():

    #open file
    inFile = open('test.txt', 'r', encoding='utf-8')

    #read in all contents of the file
    contents = inFile.read()

    #variable to store total number of vowels
    numVowel = 0

    #convert all content string to lower case so that we only need to count lower case vowel
    ###your code here

    #count total number of occurrence of vowel o.
    #we will need to do similar task for all vowels (a, e, i, o, u)
    ###your code here

    #print result
    print('test.txt has', numVowel, 'vowel occurence')
    
    #close file
    inFile.close()

vowelCounter()
