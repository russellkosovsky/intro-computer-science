#COM110: lineCounter.py
#This program count the total number of lines in the file

def lineCounter():
    #open file
    inFile = open('test.txt', 'r', encoding='utf-8')
    
    #read all lines from the file
    ###your code here


    #print result (i.e. test.txt has xxx lines)
    ###your code here

    
    #close file
    inFile.close()

lineCounter()
