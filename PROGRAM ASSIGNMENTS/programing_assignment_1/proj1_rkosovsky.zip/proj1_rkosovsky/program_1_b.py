# file: program_1_b.py
# program used to convert a group of people’s heights from English to metric and then find the group’s average height
# Author: Russell Kosovsky (rkosovsky@conncoll.edu)

def main():
# define main variable that is used to run the program.
    print("This program is used to convert a group of people’s heights from English measurements to metric measurments and then to find the group’s average height. ")
    ppl = eval(input("How many people are in your group? "))
    # assign variable for how many people are in the group. the number is inputted by the user
    total = 0
    # accumulator
    for i in range(ppl):
        n = i+1   #for printing person nuber 1,2,3 ect. 
        print("Person " + str(n))
        ft,inc = eval(input("Enter height in feet and inches, separated by a comma: "))
        ft_to_in = (ft * 12 + inc)
        in_to_m = (ft_to_in * 0.0254)
        print("The height of person " + str(n) + " in feet and inches is: ", end=""), print(ft,inc)
        print("The height of person " + str(n) + " in meters is: ", end =""), print(round(in_to_m, 2))
        # round to 2 decimal places so its easier to read
        # took me so long to figure out how to print the (in_to_m and ft,inc) variables because I was trying to concoctinate them with (+) and it didnt work because they are not strings.
        total = total + in_to_m
        #I eventually figured out that this line (above) had to be inside the loop so that it will repeat and add to the total each time.
    avrg_m = total / ppl
    avrg_in = (total / 0.0254) / ppl
    avrg_ft = int(avrg_in / 12)
    # int so its a whole number
    avrg_in_2 = int(avrg_in % 12)
    # int so its a whole number
    print("The average height of this group in meters is:", round(avrg_m, 2),"meters")
    # round to 2 decimal places so its easier to read
    print()
    # new line
    print("The average height of this group in feet and inches:", avrg_ft, "feet", avrg_in_2, "inches")
    
main()
# run program

